To get started:

1. Create a new project in Unity 4.
2. Set the Platform to iOS in Build Settings.
3. Open Player Settings and set a Bundle Identifier for your app.
4. Import the PointCloudUnityPlugin package. 
5. Look for the PointCloud menu in the menu bar to request and set Application Key.
6. Open TestScene in Assets/Plugins/PointCloud/TestScene.
7. Build & Run.